//
// Created by JerryZhang on 2018-11-22.
//
#include <stdio.h>

int sum(int arr[][5], int r, int c) {
    int s=0;
    for(int i=0;i<r;i++){
        for (int j=0;j<c;j++)
            s+=arr[i][c];
    }
    return s;
}

typedef struct {
    float x;
    float y;
} coordinate;

int coordinateFunc(){
    coordinate p1 = {0, 0};
    coordinate p2 = {.x = 1, .y = 3};
    coordinate p3;
    coordinate p4;
    p3.x = 2.0;
    p3.y = 7.0;
    p4 = p3;
    printf("p1 = (%.0f, %.0f)\n", p1.x, p1.y);
    printf("p2 = (%.0f, %.0f)\n", p2.x, p2.y);
    printf("p3 = (%.0f, %.0f)\n", p3.x, p3.y);
    printf("p4 = (%.0f, %.0f)\n", p4.x, p4.y);
    return 0;
};


constPointer(){
    int a = 3;
    int const b = 5;
    int c = 7;
    int * const ptr1 = &a;
//    printf("%d", *ptr1);
    *ptr1 = c;
//    printf("%d", a);
    int const * ptr2 = &b;
    ptr2 = &c;
    printf("%d", *ptr2);
}
long factorial(int);
int factorial2(){
    int n;
    long f;
    long (*ptr)(int);
    ptr = &factorial;
    printf("Enter an non-negative integer: ");
    scanf_s("%d", &n);
    if(n < 0)
        printf("Negative integers are not allowed. \n");
    else{
        f = ptr(n);
    }
    printf("%d! = %ld\n", n, f);
    return 0;
}
long factorial(int n){
    if (n == 0){
        return 1;
    } else {
        return (n * factorial(n-1));
    }
}

float f2c(int fahrenheit);
int fahrenheit(void){
    int fahrenheit;
    printf("Enter the temperature in degrees fahrenheit: ");
    scanf_s("%d", &fahrenheit);
    printf("The corresponding temperature in celsius is %.1f\n",f2c(fahrenheit));
    return 0;
}

float f2c(int fahrenheit){
    float celsius;
    celsius = (float) ((5.0 / 9) * (fahrenheit - 32));
    return celsius;
}

static void swap(int *a, int *b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

void bubbleSort(int numbers[], int array_size){
    int i, j;
    for (i = (array_size - 1); i > 0; i--){
        for(j = 1; j<= i; j++){
            if (numbers[j-1] > numbers[j]){
                swap(&numbers[j-1], &numbers[j]);
            }
        }
    }
}
extern void bubbleSort(int[], int);
void bubble(){
    int array[10], numberOfElements;
    printf("Enter number of elements: ");
    scanf_s("%d", &numberOfElements);
    printf("Enter %d integers: ", numberOfElements);
    for (int i = 0; i < numberOfElements; ++i) {
        scanf_s("%d", &array[i]);
    }
    bubbleSort(array, numberOfElements);
    printf("Sorted list (ascending order): ");
    for (int i = 0; i < numberOfElements; ++i) {
        printf("%d ", array[i]);
    }
}

format(){
    int a, b;
    float c, d;
    a = 7;
    b = a / 2;
    c = 10.5;
    d = c / 2;
    printf("%d\n", b);
    printf("%3d\n", b);
    printf("%3.2f\n", c);
    printf("%3.3f\n", d);
}
float getAverage(float list[], int size){
    float sum = 0.0;
    float average;
    for (int i = 0; i < size; i++) {
        sum = sum + list[i];
    }
    average = (sum / size);
    return average;
}
getAverageMain(){
    float numbers[5] = {1, 2.5, 9, 11.5, 23.5};
    printf("Array average: %.1f. \n", getAverage(numbers, 5));
}


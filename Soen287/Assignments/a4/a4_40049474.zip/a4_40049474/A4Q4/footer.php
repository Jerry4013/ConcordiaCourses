<div class="footer">
    <h3><a href="home.php">Home</a></h3>
    <h3>Copyright © 2018 Jingchao Zhang</h3>
    <h3>All rights reserved  <a href="privacy-policy.php">Privacy Statement</a></h3>
</div>
</body>
</html>

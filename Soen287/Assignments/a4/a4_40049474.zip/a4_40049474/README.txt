Note:

For Question 4, start the program from home.php.

If you cannot get a result from the search, it may be because there is not enough data. In this case, open createCottage.php, click the button will randomly create a new item in the file cottage.txt. Click this button several times until the data amount is large enough for your critia.
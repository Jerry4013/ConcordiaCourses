var threem = 0;
var fivem = 0;
var inputArray = [];
var gett = true;
var i = 0;
var index = 0;

// infinite loop
/*
for(i = 0; i >= 0; i++){
    inputArray[i] = prompt("Please enter a number: \n")

    if(inputArray[i] == -1){
        break;
    }
    if(!isNaN(inputArray[i]))
        count++;
}
*/

var temporary = prompt("Please enter a number: \n");

while(temporary != -1){
    //var temporary = prompt("Please enter a number: \n");

    if(!isNaN(temporary) && temporary != -1){
        inputArray[index] = temporary;
        index++;
    }

    temporary = prompt("Please enter a number: \n");
    /*
    if(temporary == -1){
        gett = false;
    }
    */
}


/*
for(i = 0; i < inputArray.length; i++){
    if(typeof inputArray[i] == 'number')
        count++
}
*/

for(i = 0; i < inputArray.length; i++){
    if(inputArray[i] % 3 == 0){
        threem++;
    }
}

for(i = 0; i < inputArray.length; i++){
    if(inputArray[i] % 5 == 0){
        fivem++;
    }
}

document.write("You entered " + inputArray.length + " numbers<br />");
document.write("Multiple of 3: " + threem + " numbers<br />");
document.write("Multiple of 3: " + fivem + " numbers");